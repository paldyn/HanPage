# HWP 2020 MCP Client 설정 안내

이 문서는 사용자 PC 또는 VS Code에서 HWP/HWPX 파일을 원격 HWP 2020 변환 서버로 보내 PDF/HWPX/HWP로 변환하는 client 설정 방법을 설명한다.

서버 구축 및 운영 절차는 이 문서의 범위가 아니다. 이 문서는 client 배포본과 client 등록/사용 방법만 다룬다.

## 1. 개요

권장 흐름은 다음과 같다.

1. 사용자 PC의 MCP bridge가 local HWP/HWPX 파일을 읽는다.
2. bridge가 파일 바이너리를 원격 MCP 변환 서버로 전송한다.
3. 원격 서버가 Hancom Office 2020으로 변환한다.
4. bridge가 변환 결과 바이너리를 받아 사용자 PC의 지정한 output directory에 저장한다.

따라서 `input_path`와 `output_dir`은 모두 사용자 PC의 local 경로다. 사용자는 서버 내부 경로를 알 필요가 없다.

## 2. 준비물

관리자에게 아래 정보를 받는다.

- MCP client package
  - 예: `hwp-convert-mcp-client-20260709-231800.tar.gz`
- MCP server URL
  - `.env.local`의 `HWP2020_MCP_SERVER_URL` 값
- MCP auth token
  - 개인 또는 팀별로 발급된 bearer token

주의:

- 토큰은 Git에 커밋하지 않는다.
- VS Code 설정 파일에 토큰을 직접 쓰지 말고 `.env.local`에 둔다.
- tar.gz 파일 경로와 `.env.local` 경로는 VS Code가 접근 가능한 절대경로로 적는다.
- 터미널 직접 변환 CLI인 `hwp2020-mcp-convert`는 해당 명령이 포함된 최신 client 배포본이 필요하다. 오래된 `20260707-308464b` 배포본에는 `hwp2020-mcp-bridge`만 있다.

## 3. `.env.local` 작성

사용자 PC에 `.env.local` 파일을 만든다.

예:

```env
HWP2020_MCP_SERVER_URL=http://<server-ip>:3001/mcp
HWP2020_MCP_AUTH_TOKEN=<관리자에게_받은_토큰>
```

예시 위치:

```text
/Users/tsjang/Cloud/Devel/hwp-convert/.env.local
```

client 배포본에는 `.env.local.example`도 포함된다. 복사해서 실제 토큰만 바꿔도 된다.

## 4. `npx` 절대경로 확인

macOS GUI에서 실행되는 VS Code는 shell PATH를 그대로 받지 못할 수 있으므로 `npx`는 절대경로로 등록하는 것을 권장한다.

터미널에서 확인:

```bash
which npx
```

Apple Silicon Homebrew 환경에서는 보통 다음 경로다.

```text
/opt/homebrew/bin/npx
```

Intel Mac 또는 다른 Node 설치 방식에서는 다음과 같을 수 있다.

```text
/usr/local/bin/npx
```

## 5. VS Code MCP 설정

VS Code에서 명령 팔레트를 열고 user 설정을 열 수 있다.

```text
MCP: Open User Configuration
```

워크스페이스 단위로 설정하려면 아래 파일을 만든다.

```text
.vscode/mcp.json
```

권장 설정 예:

```json
{
  "servers": {
    "hwp2020Convert": {
      "type": "stdio",
      "command": "/opt/homebrew/bin/npx",
      "args": [
        "-y",
        "--package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260709-231800.tar.gz",
        "--",
        "hwp2020-mcp-bridge"
      ],
      "envFile": "/Users/tsjang/Cloud/Devel/hwp-convert/.env.local",
      "env": {
        "PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
      }
    }
  }
}
```

사용자별로 반드시 바꿔야 하는 값:

- `command`
  - `which npx` 결과
- `--package=file:...`
  - MCP client tar.gz 파일의 절대경로
- `envFile`
  - `.env.local` 파일의 절대경로

`--package=./파일명.tar.gz`는 npm 버전과 현재 작업 디렉터리에 따라 엉뚱한 경로로 해석될 수 있다. macOS/VS Code에서는 `--package=file:/절대경로/파일명.tar.gz` 형식을 사용한다.

## 6. VS Code MCP access 허용

VS Code user settings에서 MCP 접근이 차단되어 있으면 `mcp.json`이 맞아도 `MCP: List Servers`에 서버가 보이지 않을 수 있다.

macOS VS Code user settings 경로:

```text
/Users/tsjang/Library/Application Support/Code/User/settings.json
```

다음 설정을 추가한다.

```json
{
  "chat.mcp.access": "all"
}
```

설정 후 VS Code에서 다음을 수행한다.

```text
Developer: Reload Window
```

서버 목록 확인:

```text
MCP: List Servers
```

정상이라면 `hwp2020Convert` 서버가 보인다.

## 7. VS Code에서 변환 사용

VS Code Chat에서 다음처럼 요청한다.

```text
Use hwp2020Convert to convert /Users/tsjang/rhwp/samples/sample.hwp to pdf and save it to /Users/tsjang/rhwp/converted.
```

한국어 요청 예:

```text
hwp2020Convert를 사용해서 /Users/tsjang/rhwp/samples/sample.hwp 파일을 pdf로 변환하고 /Users/tsjang/rhwp/converted 에 저장해줘.
```

성공하면 사용자 PC의 `output_dir`에 변환 파일이 저장된다.

## 8. stdio bridge MCP tool

VS Code stdio bridge가 등록하는 tool 이름:

```text
convert_local_document
```

필수 인자:

```json
{
  "input_path": "/Users/tsjang/rhwp/samples/sample.hwp",
  "target": "pdf",
  "output_dir": "/Users/tsjang/rhwp/converted"
}
```

선택 인자:

```json
{
  "output_filename": "sample-2020.pdf",
  "timeout_seconds": 240,
  "clear_distribution": false,
  "table_patch_last_row_count": false,
  "disable_pdf_hwpx_fallback": true,
  "allow_sibling_fallbacks": false
}
```

선택 인자 설명:

- `output_filename`
  - 저장할 출력 파일명이다. 디렉터리는 `output_dir`을 사용한다.
  - 확장자가 없으면 `target`에 맞는 확장자가 붙는다.
  - 생략하면 `<원본파일명>-2020.<target>` 형태를 사용한다.
- `timeout_seconds`
  - 원격 변환 작업 제한 시간이다.
  - 허용 범위는 10초부터 1800초까지이며, 기본값은 180초다.
  - 큰 문서나 이미지가 많은 문서는 600 또는 900처럼 늘릴 수 있다.
- `clear_distribution`
  - HWP 배포용/제한 플래그를 제거한 임시 입력본으로 변환을 재시도하도록 요청한다.
  - 기본값은 `false`다.
  - 문서 소유권과 정책상 허용되는 파일에만 사용한다. 제한 문서를 우회 처리하려는 목적이면 사용하지 않는다.
- `table_patch_last_row_count`
  - 일부 표 문서에서 마지막 행 개수 메타데이터 문제로 변환이 실패하는 경우 보정 전처리를 요청한다.
  - 기본값은 `false`다.
  - 일반 문서에는 켤 필요가 없고, 표 관련 오류가 재현되는 샘플에만 사용한다.
- `disable_pdf_hwpx_fallback`
  - PDF 변환 실패 시 HWPX를 거치는 fallback 경로를 비활성화할지 결정한다.
  - 기본값은 `true`다.
  - `true`이면 요청한 원본에서 바로 PDF 변환을 시도하고, 숨은 fallback으로 결과가 달라지는 것을 막는다.
  - `false`이면 서버가 허용하는 경우 HWPX 경유 fallback을 사용할 수 있다.
- `allow_sibling_fallbacks`
  - 입력 파일과 같은 위치의 형제 파일을 fallback 입력으로 사용할지 결정한다.
  - 기본값은 `false`다.
  - MCP client가 바이너리를 서버로 보내는 구조에서는 사용자가 지정한 파일만 변환하는 것이 원칙이므로 보통 `false`로 둔다.

허용되지 않는 top-level argument는 bridge에서 거부된다. 예를 들어 `server_command`, `server_arg`, `server_cwd` 같은 실행 명령 주입성 파라미터는 허용하지 않는다.

지원 변환:

```text
hwp  -> pdf | hwpx | hwp
hwpx -> pdf | hwp
```

기본 출력 파일명은 `<원본파일명>-2020.<target>` 형태다.

## 9. direct CLI 변환

VS Code 없이 터미널에서 직접 변환할 때는 `hwp2020-mcp-convert`를 사용한다.

도움말:

```bash
/opt/homebrew/bin/npx -y \
  --package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260709-231800.tar.gz \
  -- \
  hwp2020-mcp-convert --help
```

변환 예:

```bash
/opt/homebrew/bin/npx -y \
  --package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260709-231800.tar.gz \
  -- \
  hwp2020-mcp-convert \
  --env-file /Users/tsjang/Cloud/Devel/hwp-convert/.env.local \
  --input /Users/tsjang/rhwp/samples/sample.hwp \
  --target pdf \
  --output-dir /Users/tsjang/rhwp/pdf \
  --output-filename sample-2020.pdf \
  --timeout-seconds 900
```

성공 시 JSON으로 `output_path`, `size`, `sha256`, server job 정보가 출력된다.

## 10. bridge 도움말 확인

VS Code 등록 전에 bridge 도움말을 확인할 수 있다.

```bash
/opt/homebrew/bin/npx -y \
  --package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260709-231800.tar.gz \
  -- \
  hwp2020-mcp-bridge --help
```

정상이라면 `convert_local_document` tool 설명과 필수 인자가 출력된다. 이 명령은 파일을 변환하지 않고 stdio MCP bridge 사용법만 보여준다.

## 11. remote HTTP 직접 등록

일부 MCP client는 local stdio bridge 없이 원격 Streamable HTTP MCP server를 직접 등록할 수 있다.

주의:

- 이 방식은 사용자 PC의 local path를 서버가 직접 읽는 구조가 아니다.
- MCP client가 파일 바이너리를 읽어 `input_blob`으로 전달할 수 있을 때 사용한다.
- 일반 VS Code local 파일 변환에는 stdio bridge 등록을 권장한다.

HTTP 직접 등록 예:

```json
{
  "inputs": [
    {
      "type": "promptString",
      "id": "hwp2020-mcp-token",
      "description": "HWP Convert MCP auth token",
      "password": true
    }
  ],
  "servers": {
    "hwp2020Convert": {
      "type": "http",
      "url": "http://<server-ip>:3001/mcp",
      "headers": {
        "Authorization": "Bearer ${input:hwp2020-mcp-token}"
      }
    }
  }
}
```

원격 HTTP tool 이름:

```text
convert_document
```

허용 top-level argument:

- `input_filename`
- `input_blob`
- `target`
- `output_filename`
- `options`

`options` 내부 허용 key:

- `timeout_seconds`
- `clear_distribution`
- `table_patch_last_row_count`
- `disable_pdf_hwpx_fallback`
- `allow_sibling_fallbacks`

각 option의 의미와 기본 사용 방침은 위 `convert_local_document` 선택 인자 설명과 같다. remote HTTP 직접 등록에서도 서버는 허용 key 외의 값을 거부한다.

그 외 이상한 파라미터는 서버에서 거부된다.

## 12. 문제 해결

### `MCP: List Servers`에 보이지 않는 경우

아래를 확인한다.

- `.vscode/mcp.json` 또는 user MCP 설정 위치가 맞는지
- `settings.json`에 `"chat.mcp.access": "all"`이 있는지
- `command`가 `/opt/homebrew/bin/npx`처럼 절대경로인지
- `env.PATH`에 Node/npm 경로가 포함되어 있는지
- 설정 후 `Developer: Reload Window`를 실행했는지

### `npx` 또는 `node`를 찾지 못하는 경우

`command`에 `npx`만 쓰지 말고 절대경로를 사용한다.

```bash
which npx
```

확인한 경로를 `mcp.json`의 `command`에 넣는다.

### tarball을 찾지 못하는 경우

`--package=./파일명.tar.gz` 대신 `file:`이 붙은 절대경로를 사용한다.

```text
--package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260709-231800.tar.gz
```

### `hwp2020-mcp-convert: command not found`

사용 중인 client tarball이 오래된 버전일 수 있다. `hwp2020-mcp-convert`가 포함된 최신 client 배포본을 사용한다.

VS Code MCP bridge만 사용할 경우에는 `hwp2020-mcp-bridge`만 있어도 된다. 터미널 직접 변환에는 `hwp2020-mcp-convert`가 필요하다.

### `401 Unauthorized`

아래를 확인한다.

- `.env.local`에 `HWP2020_MCP_AUTH_TOKEN`이 있는지
- 토큰 앞뒤에 공백이나 따옴표가 잘못 들어가지 않았는지
- `HWP2020_MCP_SERVER_URL`이 `/mcp`까지 포함하는지

### 변환 결과가 저장되지 않는 경우

`output_dir`은 서버 경로가 아니라 사용자 PC의 local 경로다.

예:

```json
{
  "input_path": "/Users/tsjang/rhwp/samples/sample.hwp",
  "target": "pdf",
  "output_dir": "/Users/tsjang/rhwp/converted"
}
```

`output_dir`이 없으면 bridge가 자동 생성한다. 단, 상위 경로에 쓰기 권한이 있어야 한다.

### 문서 보호 또는 출력 제한 문서

서버 정책과 Hancom Office 2020 변환 결과에 따라 출력 제한 문서는 실패할 수 있다. 실패 시 client는 실패 JSON을 반환하고 output file을 생성하지 않는다.

## 13. 사용자에게 전달할 파일

client 사용자에게는 아래만 전달하면 된다.

- `hwp-convert-mcp-client-20260709-231800.tar.gz`
- MCP server URL
- MCP auth token
- 이 문서: `HWP2020_MCP_CLIENT_SETUP.md`
