#!/usr/bin/env node
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { basename, extname, isAbsolute, join, resolve } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { normalizePdfPageSetup } from "./hwp2020_mcp_page_setup.mjs";

const defaultServerUrl = "";

function usage() {
  return [
    "Usage:",
    "  hwp2020-mcp-convert --env-file .env.local --input INPUT.hwp --target pdf --output-dir OUT_DIR",
    "  node tools/hwp2020_mcp_client_convert.mjs --server-url http://host:3001/mcp --auth-token TOKEN --input INPUT.hwp --target pdf --output-dir OUT_DIR",
    "",
    "Options:",
    "  --env-file PATH           Optional .env file with HWP2020_MCP_SERVER_URL and HWP2020_MCP_AUTH_TOKEN",
    "  --server-url URL          Remote Streamable HTTP MCP endpoint, default HWP2020_MCP_SERVER_URL",
    "  --auth-token TOKEN        Required bearer token, default HWP2020_MCP_AUTH_TOKEN",
    "  --input PATH              Local HWP/HWPX path read by the MCP client",
    "  --target pdf|hwpx|hwp     Conversion target",
    "  --output-dir DIR          Local directory where the MCP client saves the converted file",
    "  --output-filename NAME    Optional output filename",
    "  --timeout-seconds N       Conversion and MCP request timeout, default 180",
    "  --password-stdin          Read encrypted .hwp password from standard input first line",
    "  --paper-size NAME         PDF only: a3 | a4 | a5 | b4 | letter | legal",
    "  --orientation NAME        PDF only: portrait | landscape",
    "",
    "npx example:",
    "  npx -y --package=file:/path/to/hwp-convert-mcp-client.tar.gz -- hwp2020-mcp-convert --env-file /path/to/.env.local --input sample.hwp --target pdf --output-dir ./out",
  ].join("\n");
}

function parseArgs(argv) {
  const options = {
    timeoutSeconds: 180,
  };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const next = () => {
      index += 1;
      if (index >= argv.length) {
        throw new Error(`missing value for ${arg}`);
      }
      return argv[index];
    };
    if (arg === "--help" || arg === "-h") {
      options.help = true;
    } else if (arg === "--input") {
      options.input = next();
    } else if (arg === "--target") {
      options.target = next();
    } else if (arg === "--output-dir") {
      options.outputDir = next();
    } else if (arg === "--output-filename") {
      options.outputFilename = next();
    } else if (arg === "--timeout-seconds") {
      options.timeoutSeconds = Number.parseInt(next(), 10);
    } else if (arg === "--password-stdin") {
      options.passwordStdin = true;
    } else if (arg === "--paper-size") {
      options.paperSize = next();
    } else if (arg === "--orientation") {
      options.orientation = next();
    } else if (arg === "--server-url") {
      options.serverUrl = next();
    } else if (arg === "--auth-token") {
      options.authToken = next();
    } else if (arg === "--env-file") {
      options.envFile = next();
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  return options;
}

function readPasswordFromStdin() {
  const value = readFileSync(0, "utf8");
  return value.split(/\r?\n/, 1)[0];
}

function parseEnvFile(filePath) {
  const envPath = localPath(filePath);
  if (!existsSync(envPath) || !statSync(envPath).isFile()) {
    throw new Error(`env file does not exist: ${envPath}`);
  }
  const result = {};
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }
    const equalsAt = trimmed.indexOf("=");
    if (equalsAt < 1) {
      continue;
    }
    const key = trimmed.slice(0, equalsAt).trim();
    let value = trimmed.slice(equalsAt + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }
  return result;
}

function applyEnvironmentDefaults(options) {
  const fileEnv = options.envFile ? parseEnvFile(options.envFile) : {};
  if (!options.serverUrl) {
    options.serverUrl = fileEnv.HWP2020_MCP_SERVER_URL || process.env.HWP2020_MCP_SERVER_URL || defaultServerUrl;
  }
  if (!options.authToken) {
    options.authToken = fileEnv.HWP2020_MCP_AUTH_TOKEN || process.env.HWP2020_MCP_AUTH_TOKEN || "";
  }
  return options;
}

function localPath(pathValue) {
  const value = String(pathValue || "").trim();
  if (!value) {
    throw new Error("path value must not be empty");
  }
  return resolve(isAbsolute(value) ? value : join(process.cwd(), value));
}

function safeBasename(name, fallback) {
  const clean = basename(String(name || "")).replaceAll("\0", "");
  return clean && clean !== "." && clean !== ".." ? clean : fallback;
}

function normalizeTarget(value) {
  const target = String(value || "").toLowerCase();
  if (!["pdf", "hwpx", "hwp"].includes(target)) {
    throw new Error("target must be one of: pdf, hwpx, hwp");
  }
  return target;
}

function outputFilename(inputPath, target, requestedName) {
  const stem = basename(inputPath, extname(inputPath));
  let name = requestedName ? safeBasename(requestedName, `${stem}-2020.${target}`) : `${stem}-2020.${target}`;
  if (!name.toLowerCase().endsWith(`.${target}`)) {
    name = `${name}.${target}`;
  }
  return name;
}

function sha256(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

function validateOptions(options) {
  if (options.help) {
    return;
  }
  if (!options.input) {
    throw new Error("--input is required");
  }
  if (!options.serverUrl) {
    throw new Error("--server-url is required");
  }
  if (!options.authToken) {
    throw new Error("--auth-token is required");
  }
  if (!options.target) {
    throw new Error("--target is required");
  }
  if (!options.outputDir) {
    throw new Error("--output-dir is required");
  }
  if (!Number.isInteger(options.timeoutSeconds) || options.timeoutSeconds < 10 || options.timeoutSeconds > 1800) {
    throw new Error("--timeout-seconds must be an integer between 10 and 1800");
  }
  normalizePdfPageSetup(normalizeTarget(options.target), {
    paper_size: options.paperSize,
    orientation: options.orientation,
  });
}

function requestTimeoutMs(timeoutSeconds) {
  return (timeoutSeconds + 120) * 1000;
}

function createTransport(options) {
  return new StreamableHTTPClientTransport(new URL(options.serverUrl), {
    requestInit: {
      headers: {
        Authorization: `Bearer ${options.authToken}`,
      },
    },
  });
}

async function convert(options) {
  const inputPath = localPath(options.input);
  const outputDir = localPath(options.outputDir);
  const target = normalizeTarget(options.target);
  const pageSetup = normalizePdfPageSetup(target, {
    paper_size: options.paperSize,
    orientation: options.orientation,
  });
  if (!existsSync(inputPath) || !statSync(inputPath).isFile()) {
    throw new Error(`input does not exist: ${inputPath}`);
  }
  if (existsSync(outputDir) && !statSync(outputDir).isDirectory()) {
    throw new Error(`output-dir is not a directory: ${outputDir}`);
  }
  mkdirSync(outputDir, { recursive: true });

  const requestedOutputName = outputFilename(inputPath, target, options.outputFilename);
  const client = new Client({ name: "hwp2020-mcp-client-convert", version: "0" }, { capabilities: {} });
  const transport = createTransport(options);

  await client.connect(transport);
  try {
    const inputBuffer = readFileSync(inputPath);
    const remoteArguments = {
      input_filename: basename(inputPath),
      input_blob: inputBuffer.toString("base64"),
      target,
      output_filename: requestedOutputName,
      options: {
        timeout_seconds: options.timeoutSeconds,
        disable_pdf_hwpx_fallback: true,
        allow_sibling_fallbacks: false,
        paper_size: pageSetup?.paperSize,
        orientation: pageSetup?.orientation,
      },
    };
    if (options.password !== undefined) {
      remoteArguments.password = options.password;
    }
    const toolResult = await client.callTool(
      {
        name: "convert_document",
        arguments: remoteArguments,
      },
      undefined,
      { timeout: requestTimeoutMs(options.timeoutSeconds) },
    );
    const result = JSON.parse(toolResult.content[0].text);
    if (toolResult.isError || result.status !== "success") {
      throw new Error(`conversion failed: ${JSON.stringify(result)}`);
    }
    const resourceContent = toolResult.content.find((item) => item.type === "resource");
    if (!resourceContent?.resource?.blob) {
      throw new Error("conversion result did not include an output blob");
    }

    const outputBuffer = Buffer.from(resourceContent.resource.blob, "base64");
    const outputPath = resolve(outputDir, safeBasename(result.output_filename, requestedOutputName));
    writeFileSync(outputPath, outputBuffer);
    const outputSha256 = sha256(outputBuffer);
    if (result.sha256 !== outputSha256) {
      throw new Error(`output sha256 mismatch: server=${result.sha256} client=${outputSha256}`);
    }

    return {
      status: "success",
      input_path: inputPath,
      output_path: outputPath,
      target,
      output_filename: basename(outputPath),
      size: outputBuffer.length,
      sha256: outputSha256,
      resource_uri: result.resource_uri,
      conversion: result.conversion,
      server: {
        job_id: result.job_id,
        run_status: result.run_status,
        validation: result.validation,
      },
    };
  } finally {
    await client.close();
  }
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return 0;
  }
  applyEnvironmentDefaults(options);
  if (options.passwordStdin) {
    options.password = readPasswordFromStdin();
  }
  validateOptions(options);
  const result = await convert(options);
  console.log(JSON.stringify(result, null, 2));
  return 0;
}

main()
  .then((code) => {
    process.exitCode = code;
  })
  .catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
