export const paperSizes = Object.freeze({
  a3: Object.freeze({ widthHwpunit: 84188, heightHwpunit: 119055 }),
  a4: Object.freeze({ widthHwpunit: 59528, heightHwpunit: 84188 }),
  a5: Object.freeze({ widthHwpunit: 41953, heightHwpunit: 59528 }),
  b4: Object.freeze({ widthHwpunit: 72850, heightHwpunit: 103181 }),
  letter: Object.freeze({ widthHwpunit: 61200, heightHwpunit: 79200 }),
  legal: Object.freeze({ widthHwpunit: 61200, heightHwpunit: 100800 }),
});

export const paperSizeNames = Object.freeze(Object.keys(paperSizes));
export const orientationNames = Object.freeze(["portrait", "landscape"]);

function optionalEnum(value, name, values) {
  if (value === undefined) {
    return undefined;
  }
  if (typeof value !== "string") {
    throw new Error(`options.${name} must be one of: ${values.join(", ")}`);
  }
  const normalized = value.trim().toLowerCase();
  if (!values.includes(normalized)) {
    throw new Error(`options.${name} must be one of: ${values.join(", ")}`);
  }
  return normalized;
}

export function normalizePdfPageSetup(target, options = {}) {
  const paperSize = optionalEnum(options.paper_size, "paper_size", paperSizeNames);
  const orientation = optionalEnum(options.orientation, "orientation", orientationNames);
  if ((paperSize || orientation) && target !== "pdf") {
    throw new Error("options.paper_size and options.orientation are supported only for pdf target");
  }
  if (!paperSize && !orientation) {
    return null;
  }
  const paper = paperSize ? paperSizes[paperSize] : null;
  return {
    paperSize,
    orientation,
    widthHwpunit: paper?.widthHwpunit ?? null,
    heightHwpunit: paper?.heightHwpunit ?? null,
    landscape: orientation === undefined ? null : orientation === "landscape" ? 1 : 0,
  };
}
