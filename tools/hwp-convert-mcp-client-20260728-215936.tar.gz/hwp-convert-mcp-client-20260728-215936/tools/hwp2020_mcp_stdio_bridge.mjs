#!/usr/bin/env node
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { basename, extname, isAbsolute, join, resolve } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import * as z from "zod/v4";
import { normalizePdfPageSetup, orientationNames, paperSizeNames } from "./hwp2020_mcp_page_setup.mjs";

const defaultServerUrl = "";
const allowedCliArgs = new Set(["--server-url", "--auth-token", "--help", "-h"]);
const allowedToolArgs = new Set([
  "input_path",
  "target",
  "output_dir",
  "output_filename",
  "password",
  "timeout_seconds",
  "clear_distribution",
  "table_patch_last_row_count",
  "disable_pdf_hwpx_fallback",
  "allow_sibling_fallbacks",
  "paper_size",
  "orientation",
]);

function usage() {
  return [
    "Usage:",
    "  hwp2020-mcp-bridge [--server-url URL] [--auth-token TOKEN]",
    "",
    "This command starts a stdio MCP bridge. It does not convert a file by itself.",
    "Register it in VS Code or another MCP client, then call the MCP tool below.",
    "",
    "MCP tool:",
    "  convert_local_document",
    "",
    "Required tool arguments:",
    "  input_path     Local .hwp or .hwpx path on the MCP client machine",
    "  target         pdf | hwpx | hwp",
    "  output_dir     Local directory where the converted file is saved",
    "",
    "Optional tool arguments:",
    "  output_filename              Output basename; extension is appended if missing",
    "  timeout_seconds              Integer from 10 to 1800, default 180; also extends MCP request wait",
    "  clear_distribution           Boolean, default false; retry with distribution flag cleared",
    "  table_patch_last_row_count   Boolean, default false; patch known table row metadata issue",
    "  disable_pdf_hwpx_fallback    Boolean, default true; keep PDF conversion on the direct path",
    "  allow_sibling_fallbacks      Boolean, default false; allow server-side sibling file fallback",
    "  password                     Optional password for encrypted .hwp or .hwpx input",
    "  paper_size                  PDF only: a3 | a4 | a5 | b4 | letter | legal",
    "  orientation                 PDF only: portrait | landscape",
    "",
    "Supported conversions:",
    "  hwp  -> pdf | hwpx | hwp",
    "  hwpx -> pdf | hwp",
    "",
    "Example MCP tool arguments:",
    "  {",
    "    \"input_path\": \"/Users/tsjang/rhwp/samples/sample.hwp\",",
    "    \"target\": \"pdf\",",
    "    \"output_dir\": \"/Users/tsjang/rhwp/converted\"",
    "  }",
    "",
    "Example VS Code chat request:",
    "  Use hwp2020Convert to convert /Users/tsjang/rhwp/samples/sample.hwp to pdf and save it to /Users/tsjang/rhwp/converted.",
    "",
    "Environment:",
    "  HWP2020_MCP_SERVER_URL    Remote Streamable HTTP MCP endpoint",
    "  HWP2020_MCP_AUTH_TOKEN    Required bearer token",
    "",
    "Recommended VS Code setup:",
    "  1. Put HWP2020_MCP_AUTH_TOKEN and HWP2020_MCP_SERVER_URL in .env.local.",
    "  2. Register this bridge in .vscode/mcp.json with envFile pointing to .env.local.",
    "  3. On macOS GUI launchers, use an absolute npx path and set env.PATH for node.",
    "",
    "VS Code npx example:",
    "  /opt/homebrew/bin/npx -y --package=file:/Users/tsjang/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-YYYYMMDD-HHMMSS.tar.gz -- hwp2020-mcp-bridge",
    "",
    "Direct CLI conversion example:",
    "  npx -y --package=file:/path/to/hwp-convert-mcp-client-YYYYMMDD-HHMMSS.tar.gz -- hwp2020-mcp-convert --env-file /path/to/.env.local --input /path/to/input.hwp --target pdf --output-dir /path/to/output",
  ].join("\n");
}

function parseArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!allowedCliArgs.has(arg)) {
      throw new Error(`unknown argument: ${arg}`);
    }
    if (arg === "--help" || arg === "-h") {
      options.help = true;
      continue;
    }
    index += 1;
    if (index >= argv.length) {
      throw new Error(`missing value for ${arg}`);
    }
    if (arg === "--server-url") {
      options.serverUrl = argv[index];
    } else if (arg === "--auth-token") {
      options.authToken = argv[index];
    }
  }
  return options;
}

function bridgeConfig(cliOptions) {
  const serverUrl = String(cliOptions.serverUrl || process.env.HWP2020_MCP_SERVER_URL || defaultServerUrl).trim();
  const authToken = String(cliOptions.authToken || process.env.HWP2020_MCP_AUTH_TOKEN || "").trim();
  if (!serverUrl) {
    throw new Error("remote MCP server URL is required");
  }
  if (!authToken) {
    throw new Error("HWP2020_MCP_AUTH_TOKEN or --auth-token is required");
  }
  return { serverUrl, authToken };
}

function rejectUnknownKeys(value, allowedKeys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return;
  }
  const unknownKeys = Object.keys(value).filter((key) => !allowedKeys.has(key));
  if (unknownKeys.length > 0) {
    throw new Error(`${label} contains unsupported key(s): ${unknownKeys.join(", ")}`);
  }
}

function validatePassword(value) {
  if (value === undefined) {
    return;
  }
  if (typeof value !== "string" || Buffer.byteLength(value, "utf8") > 4096) {
    throw new Error("password must be a string no longer than 4096 UTF-8 bytes");
  }
  if (/\r|\n/.test(value)) {
    throw new Error("password must not contain a line break");
  }
}

function expandHome(pathValue) {
  const value = String(pathValue || "").trim();
  if (value === "~") {
    return homedir();
  }
  if (value.startsWith("~/")) {
    return join(homedir(), value.slice(2));
  }
  return value;
}

function localPath(pathValue) {
  const expanded = expandHome(pathValue);
  if (!expanded) {
    throw new Error("path value must not be empty");
  }
  return resolve(isAbsolute(expanded) ? expanded : join(process.cwd(), expanded));
}

function safeBasename(name, fallback) {
  const clean = basename(String(name || "")).replaceAll("\0", "");
  return clean && clean !== "." && clean !== ".." ? clean : fallback;
}

function normalizeTarget(value) {
  const target = String(value || "").toLowerCase();
  if (!["pdf", "hwpx", "hwp"].includes(target)) {
    throw new Error("target must be one of: pdf, hwpx, hwp");
  }
  return target;
}

function validateDirection(inputPath, target) {
  const inputExt = extname(inputPath).toLowerCase();
  const allowedTargets = inputExt === ".hwp" ? new Set(["pdf", "hwpx", "hwp"]) : new Set(["pdf", "hwp"]);
  if (![".hwp", ".hwpx"].includes(inputExt)) {
    throw new Error("input_path extension must be .hwp or .hwpx");
  }
  if (!allowedTargets.has(target)) {
    throw new Error(`unsupported target '${target}' for ${inputExt}`);
  }
}

function outputFilename(inputPath, target, requestedName) {
  const stem = basename(inputPath, extname(inputPath));
  let name = requestedName ? safeBasename(requestedName, `${stem}-2020.${target}`) : `${stem}-2020.${target}`;
  if (!name.toLowerCase().endsWith(`.${target}`)) {
    name = `${name}.${target}`;
  }
  return name;
}

function sha256(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

function normalizeTimeout(value) {
  const timeoutSeconds = value ?? 180;
  if (!Number.isInteger(timeoutSeconds) || timeoutSeconds < 10 || timeoutSeconds > 1800) {
    throw new Error("timeout_seconds must be an integer between 10 and 1800");
  }
  return timeoutSeconds;
}

function requestTimeoutMs(timeoutSeconds) {
  return (timeoutSeconds + 120) * 1000;
}

function optionBoolean(args, name, fallback) {
  const value = args[name] ?? fallback;
  if (typeof value !== "boolean") {
    throw new Error(`${name} must be boolean`);
  }
  return value;
}

function createTransport(config) {
  return new StreamableHTTPClientTransport(new URL(config.serverUrl), {
    requestInit: {
      headers: {
        Authorization: `Bearer ${config.authToken}`,
      },
    },
  });
}

async function callRemoteConvert(config, payload, timeoutSeconds) {
  const client = new Client({ name: "hwp2020-mcp-stdio-bridge", version: "0.1.0" }, { capabilities: {} });
  const transport = createTransport(config);
  await client.connect(transport);
  try {
    return await client.callTool(
      {
        name: "convert_document",
        arguments: payload,
      },
      undefined,
      { timeout: requestTimeoutMs(timeoutSeconds) },
    );
  } finally {
    await client.close();
  }
}

async function convertLocalDocument(config, args) {
  rejectUnknownKeys(args, allowedToolArgs, "tool arguments");
  validatePassword(args.password);

  const inputPath = localPath(args.input_path);
  const outputDir = localPath(args.output_dir);
  const target = normalizeTarget(args.target);
  validateDirection(inputPath, target);
  const pageSetup = normalizePdfPageSetup(target, args);

  if (!existsSync(inputPath) || !statSync(inputPath).isFile()) {
    throw new Error(`input_path does not exist or is not a file: ${inputPath}`);
  }
  if (existsSync(outputDir) && !statSync(outputDir).isDirectory()) {
    throw new Error(`output_dir exists but is not a directory: ${outputDir}`);
  }
  mkdirSync(outputDir, { recursive: true });

  const inputBuffer = readFileSync(inputPath);
  const requestedOutputName = outputFilename(inputPath, target, args.output_filename);
  const timeoutSeconds = normalizeTimeout(args.timeout_seconds);
  const remoteArguments = {
    input_filename: basename(inputPath),
    input_blob: inputBuffer.toString("base64"),
    target,
    output_filename: requestedOutputName,
    options: {
      timeout_seconds: timeoutSeconds,
      clear_distribution: optionBoolean(args, "clear_distribution", false),
      table_patch_last_row_count: optionBoolean(args, "table_patch_last_row_count", false),
      disable_pdf_hwpx_fallback: optionBoolean(args, "disable_pdf_hwpx_fallback", true),
      allow_sibling_fallbacks: optionBoolean(args, "allow_sibling_fallbacks", false),
      paper_size: pageSetup?.paperSize,
      orientation: pageSetup?.orientation,
    },
  };
  if (args.password !== undefined) {
    remoteArguments.password = args.password;
  }
  const remoteResult = await callRemoteConvert(
    config,
    remoteArguments,
    timeoutSeconds,
  );

  const result = JSON.parse(remoteResult.content[0].text);
  if (remoteResult.isError || result.status !== "success") {
    throw new Error(`remote conversion failed: ${JSON.stringify(result)}`);
  }
  const resourceContent = remoteResult.content.find((item) => item.type === "resource");
  if (!resourceContent?.resource?.blob) {
    throw new Error("remote conversion result did not include an output blob");
  }

  const outputBuffer = Buffer.from(resourceContent.resource.blob, "base64");
  const outputPath = resolve(outputDir, safeBasename(result.output_filename, requestedOutputName));
  writeFileSync(outputPath, outputBuffer);
  const outputSha256 = sha256(outputBuffer);
  if (result.sha256 !== outputSha256) {
    throw new Error(`output sha256 mismatch: server=${result.sha256} client=${outputSha256}`);
  }

  return {
    status: "success",
    input_path: inputPath,
    output_path: outputPath,
    target,
    output_filename: basename(outputPath),
    size: outputBuffer.length,
    sha256: outputSha256,
    server: {
      job_id: result.job_id,
      run_status: result.run_status,
      validation: result.validation,
      resource_uri: result.resource_uri,
      conversion: result.conversion,
    },
  };
}

function createBridgeServer(config) {
  const server = new McpServer({
    name: "hwp2020-local-bridge",
    version: "0.1.0",
  });

  server.registerTool(
    "convert_local_document",
    {
      title: "Convert local HWP/HWPX document",
      description: "Read a local HWP/HWPX file, convert it through the remote Hancom Office 2020 MCP server, and save the result locally.",
      inputSchema: z.strictObject({
        input_path: z.string().describe("Local .hwp or .hwpx path on the MCP client machine."),
        target: z.enum(["pdf", "hwpx", "hwp"]).describe("Conversion target."),
        output_dir: z.string().describe("Local output directory on the MCP client machine."),
        output_filename: z.string().optional().describe("Optional local output basename. Extension is appended if missing."),
        password: z.string().max(4096).optional().describe("Optional password for encrypted .hwp or .hwpx input. It is sent only to the remote conversion request."),
        timeout_seconds: z.number().int().min(10).max(1800).optional().describe("Remote conversion timeout in seconds. Also extends the MCP request wait. Default is 180."),
        clear_distribution: z.boolean().optional().describe("Request retry with HWP distribution flag cleared. Default false; use only when document policy allows it."),
        table_patch_last_row_count: z.boolean().optional().describe("Patch a known HWP table last-row-count metadata issue before conversion. Default false."),
        disable_pdf_hwpx_fallback: z.boolean().optional().describe("Disable PDF fallback through HWPX. Default true for predictable direct PDF conversion."),
        allow_sibling_fallbacks: z.boolean().optional().describe("Allow server-side fallback to sibling files. Default false so only the requested input is converted."),
        paper_size: z.enum(paperSizeNames).optional().describe("PDF only paper size: a3, a4, a5, b4, letter, legal."),
        orientation: z.enum(orientationNames).optional().describe("PDF only orientation: portrait or landscape."),
      }),
    },
    async (args) => {
      try {
        const result = await convertLocalDocument(config, args);
        return {
          content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
          isError: false,
        };
      } catch (error) {
        return {
          content: [{ type: "text", text: JSON.stringify({ status: "failed", error: error.message }, null, 2) }],
          isError: true,
        };
      }
    },
  );

  return server;
}

async function main() {
  const cliOptions = parseArgs(process.argv.slice(2));
  if (cliOptions.help) {
    console.log(usage());
    return;
  }
  const config = bridgeConfig(cliOptions);
  const server = createBridgeServer(config);
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
