# HWP 2020 MCP Client 설정 안내

이 문서는 사용자 PC 또는 VS Code에서 HWP/HWPX 파일을 원격 HWP 2020 변환 서버로 보내 PDF/HWPX/HWP로 변환하는 client 설정 방법을 설명한다.

서버 구축 및 운영 절차는 이 문서의 범위가 아니다. 이 문서는 client 배포본과 client 등록/사용 방법만 다룬다.

## 1. 개요

짧은 문서는 기존 동기 변환을 사용해도 된다. 큰 문서는 다음 비동기 흐름을 권장한다.

1. 사용자 PC의 MCP bridge가 local HWP/HWPX 파일을 읽는다.
2. bridge 또는 CLI의 `start`가 파일 바이너리를 원격 MCP 변환 서버로 전송하고 `job_id`를 받는다.
3. 사용자 PC는 `job_id`로 단계, 경과 시간, 생성 중인 output byte, result response delivery 상태를 조회한다.
4. 완료 뒤 `save` 또는 `download`가 변환 결과 바이너리를 받아 사용자 PC의 지정한 output directory에 저장한다.
5. server는 result response write가 완료되면 output을 정리한다. write가 중단되거나 실패하면 TTL 동안
   result retrieval을 재시도할 수 있고, 수신되지 않은 결과도 TTL 뒤 정리된다.

따라서 `input_path`와 `output_dir`은 모두 사용자 PC의 local 경로다. 사용자는 서버 내부 경로를 알 필요가 없다.
`resource_uri`는 persistent download 경로가 아니며, 변환본은 MCP response의 inline binary로만 전달된다.

### 암호 문서 지원 범위

`password` tool 인자 또는 CLI `--password-stdin`으로 다음 암호 문서를 변환할 수 있다.

| 입력 | 지원 target |
| --- | --- |
| HWP3 또는 HWP5 암호 `.hwp` | `pdf`, `hwpx`, `hwp` |
| ODF AES-256-CBC/PBKDF2 암호 `.hwpx` | `pdf`, `hwp` |

CLI는 비밀번호를 standard input 첫 줄에서만 읽는다. command argument, `.env.local`, output filename에
비밀번호를 넣지 않는다. DRM 등 위 ODF 계약 밖의 암호화 문서는 지원하지 않는다.

암호 HWP5가 큰 `Contents/section0.xml`을 생성해도 server는 XML 전체를 메모리로 읽지 않고 ZIP 목록의
비압축 entry 길이로 HWPX 본문 유효성을 확인한다. 따라서 큰 본문이 client까지 전송되기 전에 잘못 거부되지 않는다.

## 2. 준비물

관리자에게 아래 정보를 받는다.

- MCP client package
  - 예: `hwp-convert-mcp-client-20260731-230819.tar.gz`
- MCP server URL
  - `.env.local`의 `HWP2020_MCP_SERVER_URL` 값
- MCP auth token
  - 개인 또는 팀별로 발급된 bearer token

주의:

- 토큰은 Git에 커밋하지 않는다.
- VS Code 설정 파일에 토큰을 직접 쓰지 말고 `.env.local`에 둔다.
- 터미널 예시의 `$HOME`은 현재 사용자의 홈 디렉터리로 shell이 확장한다. `mcp.json`에서는 shell 확장이
  없으므로 VS Code의 `${userHome}` 변수를 사용한다.
- 터미널 직접 변환 CLI인 `hwp2020-mcp-convert`는 해당 명령이 포함된 최신 client 배포본이 필요하다. 오래된 `20260707-308464b` 배포본에는 `hwp2020-mcp-bridge`만 있다.

## 3. `.env.local` 작성

사용자 PC에 `.env.local` 파일을 만든다.

예:

```env
HWP2020_MCP_SERVER_URL=<관리자가_제공한_MCP_endpoint>
HWP2020_MCP_AUTH_TOKEN=<관리자에게_받은_토큰>
```

예시 위치:

```text
$HOME/Cloud/Devel/hwp-convert/.env.local
```

client 배포본에는 `.env.local.example`도 포함된다. 복사해서 실제 토큰만 바꿔도 된다.

## 4. `npx` 절대경로 확인

macOS GUI에서 실행되는 VS Code는 shell PATH를 그대로 받지 못할 수 있으므로 `npx`는 절대경로로 등록하는 것을 권장한다.

터미널에서 확인:

```bash
which npx
```

Apple Silicon Homebrew 환경에서는 보통 다음 경로다.

```text
/opt/homebrew/bin/npx
```

Intel Mac 또는 다른 Node 설치 방식에서는 다음과 같을 수 있다.

```text
/usr/local/bin/npx
```

## 5. VS Code MCP 설정

VS Code에서 명령 팔레트를 열고 user 설정을 열 수 있다.

```text
MCP: Open User Configuration
```

워크스페이스 단위로 설정하려면 아래 파일을 만든다.

```text
.vscode/mcp.json
```

권장 설정 예:

```json
{
  "servers": {
    "hwp2020Convert": {
      "type": "stdio",
      "command": "/opt/homebrew/bin/npx",
      "args": [
        "-y",
        "--package=file:${userHome}/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz",
        "--",
        "hwp2020-mcp-bridge"
      ],
      "envFile": "${userHome}/Cloud/Devel/hwp-convert/.env.local",
      "env": {
        "PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
      }
    }
  }
}
```

사용자별로 반드시 바꿔야 하는 값:

- `command`
  - `which npx` 결과
- `--package=file:...`
  - MCP client tar.gz 파일의 절대경로. 권장 예시의 `${userHome}`은 VS Code가 현재 사용자의 홈으로
    확장한다.
- `envFile`
  - `.env.local` 파일의 절대경로. 권장 예시의 `${userHome}`을 그대로 사용할 수 있다.

`--package=./파일명.tar.gz`는 npm 버전과 현재 작업 디렉터리에 따라 엉뚱한 경로로 해석될 수 있다. macOS/VS Code에서는 `--package=file:/절대경로/파일명.tar.gz` 형식을 사용한다.

## 6. VS Code MCP access 허용

VS Code user settings에서 MCP 접근이 차단되어 있으면 `mcp.json`이 맞아도 `MCP: List Servers`에 서버가 보이지 않을 수 있다.

macOS VS Code user settings 경로:

```text
$HOME/Library/Application Support/Code/User/settings.json
```

다음 설정을 추가한다.

```json
{
  "chat.mcp.access": "all"
}
```

설정 후 VS Code에서 다음을 수행한다.

```text
Developer: Reload Window
```

서버 목록 확인:

```text
MCP: List Servers
```

정상이라면 `hwp2020Convert` 서버가 보인다.

## 7. VS Code에서 변환 사용

VS Code Chat에서 다음처럼 요청한다.

```text
Use hwp2020Convert to convert <사용자_홈>/Documents/sample.hwp to pdf and save it to <사용자_홈>/Documents/converted.
```

한국어 요청 예:

```text
hwp2020Convert를 사용해서 <사용자_홈>/Documents/sample.hwp 파일을 pdf로 변환하고 <사용자_홈>/Documents/converted 에 저장해줘.
```

성공하면 사용자 PC의 `output_dir`에 변환 파일이 저장된다. 384쪽처럼 수분 이상 걸리는 문서는 아래
async tool 흐름을 사용하고 `timeout_seconds: 900` 이상을 명시한다.

## 8. stdio bridge MCP tool

VS Code stdio bridge는 기존 동기 tool과 다음 async tool을 함께 등록한다.

```text
convert_local_document
start_local_document_conversion
get_local_conversion_status
save_local_conversion_result
```

### 기존 동기 변환

필수 인자:

```json
{
  "input_path": "<사용자_홈>/Documents/sample.hwp",
  "target": "pdf",
  "output_dir": "<사용자_홈>/Documents/converted"
}
```

선택 인자:

```json
{
  "output_filename": "sample-2020.pdf",
  "password": "<암호화된_hwp_또는_hwpx의_암호>",
  "timeout_seconds": 240,
  "clear_distribution": false,
  "table_patch_last_row_count": false,
  "disable_pdf_hwpx_fallback": true,
  "allow_sibling_fallbacks": false,
  "paper_size": "a4",
  "orientation": "landscape"
}
```

선택 인자 설명:

- `output_filename`
  - 저장할 출력 파일명이다. 디렉터리는 `output_dir`을 사용한다.
  - 확장자가 없으면 `target`에 맞는 확장자가 붙는다.
  - 생략하면 `<원본파일명>-2020.<target>` 형태를 사용한다.
- `password`
  - 암호가 설정된 `.hwp` 또는 `.hwpx`를 변환할 때 지정하는 선택 문자열이다.
  - `.hwp`는 HWP3 또는 HWP5 암호 문서를 지원하며, 서버가 암호 종류에 따라 rhwp 또는 HWP3 복호화 도구에 stdin으로 암호를 전달해 job 전용 HWPX intermediate를 만든다. `.hwpx`는 ODF AES-256-CBC/PBKDF2 복호화 도구로 job 전용 HWPX intermediate를 만든다.
  - PDF와 HWP output은 Hancom Office 2020이 이 intermediate를 변환하며, HWPX input의 PDF/HWP output만 지원한다. `.hwpx -> .hwpx`는 변환 방향 자체가 지원되지 않는다.
  - DRM 등 ODF AES-256-CBC/PBKDF2 계약 밖의 암호화 문서는 지원하지 않는다.
  - PDF에서는 text-rich HWPX intermediate의 source text량과 `pdftotext` 결과를 추가로 비교한다. text 추출량이 낮으면 1·중간·마지막 페이지의 raster ink ratio로 본문을 한 번 더 확인한다. 두 검사 모두 부족한 PDF는 MCP failure로 처리하며, client output directory에 저장하지 않는다. 이는 구조적으로 유효하지만 본문을 보존하지 못한 PDF를 성공 결과로 오인하지 않기 위한 보호 장치다.
  - 암호 값은 변환 결과, 파일명, server 응답에 포함하지 않는다. 다만 MCP client 또는 VS Code Chat에 직접 입력한 암호의 보관·로그 정책은 사용하는 client 제품의 보안 설정을 따른다.
- `timeout_seconds`
  - 원격 변환 작업 제한 시간이다.
  - 허용 범위는 10초부터 1800초까지이며, 기본값은 900초다.
  - 큰 문서나 이미지가 많은 문서는 600 또는 900처럼 늘릴 수 있다.
  - client는 MCP 요청 대기 시간도 이 값에 여유 시간 120초를 더해 설정한다. 따라서 긴 문서에서 SDK 기본 60초 요청 timeout으로 먼저 종료되는 것을 피한다.
- `clear_distribution`
  - HWP 배포용/제한 플래그를 제거한 임시 입력본으로 변환을 재시도하도록 요청한다.
  - 기본값은 `false`다.
  - 문서 소유권과 정책상 허용되는 파일에만 사용한다. 제한 문서를 우회 처리하려는 목적이면 사용하지 않는다.
- `table_patch_last_row_count`
  - 일부 표 문서에서 마지막 행 개수 메타데이터 문제로 변환이 실패하는 경우 보정 전처리를 요청한다.
  - 기본값은 `false`다.
  - 일반 문서에는 켤 필요가 없고, 표 관련 오류가 재현되는 샘플에만 사용한다.
- `disable_pdf_hwpx_fallback`
  - PDF 변환 실패 시 HWPX를 거치는 fallback 경로를 비활성화할지 결정한다.
  - 기본값은 `true`다.
  - `true`이면 요청한 원본에서 바로 PDF 변환을 시도하고, 숨은 fallback으로 결과가 달라지는 것을 막는다.
  - `false`이면 서버가 허용하는 경우 HWPX 경유 fallback을 사용할 수 있다.
- `allow_sibling_fallbacks`
  - 입력 파일과 같은 위치의 형제 파일을 fallback 입력으로 사용할지 결정한다.
  - 기본값은 `false`다.
  - MCP client가 바이너리를 서버로 보내는 구조에서는 사용자가 지정한 파일만 변환하는 것이 원칙이므로 보통 `false`로 둔다.
- `paper_size`
  - PDF 변환에서 출력 용지를 명시한다. 허용값은 `a3`, `a4`, `a5`, `b4`, `letter`, `legal`이다.
  - 실무에서 자주 쓰는 값은 `a4` (210 x 297 mm), `a3` (297 x 420 mm),
    `b4` (Korean/JIS B4, 257 x 364 mm)다.
  - PDF target에서만 사용할 수 있다. `hwp` 또는 `hwpx` target에 지정하면 변환 전에 요청이 거부된다.
  - 생략하면 원본 문서의 용지 설정을 유지한다.
- `orientation`
  - PDF 변환의 방향을 `portrait` 또는 `landscape`로 지정한다.
  - PDF target에서만 사용할 수 있다. 생략하면 원본 문서의 방향을 유지한다.
  - 명시하면 한글 2020의 `PageSetup`을 whole document에 적용한다. 따라서 내용 재조판으로 페이지 수가 변할 수 있다.

용지/방향 지정 예:

```json
{
  "input_path": "<사용자_홈>/Documents/sample.hwp",
  "target": "pdf",
  "output_dir": "<사용자_홈>/Documents/converted",
  "paper_size": "a4",
  "orientation": "landscape"
}
```

허용되지 않는 top-level argument는 bridge에서 거부된다. 예를 들어 `server_command`, `server_arg`, `server_cwd` 같은 실행 명령 주입성 파라미터는 허용하지 않는다.

암호 HWP/HWPX의 VS Code 요청 예:

```text
hwp2020Convert를 사용해서 /Users/me/Documents/locked.hwpx를 password와 함께 pdf로 변환하고 /Users/me/Documents/converted에 저장해줘.
```

지원 변환:

```text
hwp  -> pdf | hwpx | hwp
hwpx -> pdf | hwp
```

기본 출력 파일명은 `<원본파일명>-2020.<target>` 형태다.

### 장시간 문서 async 변환

`start_local_document_conversion`은 동기 result를 기다리지 않고 local input을 upload한 뒤 `job_id`를
반환한다. 이 tool에는 `output_dir`을 넣지 않는다. output은 완료 후 save 단계에서 사용자 PC에만 쓴다.

```json
{
  "input_path": "/Users/me/Documents/large-manual.hwpx",
  "target": "pdf",
  "output_filename": "large-manual-2020.pdf",
  "timeout_seconds": 900
}
```

`get_local_conversion_status`에는 `job_id`만 넣는다.

```json
{
  "job_id": "<start가_반환한_UUID>",
  "timeout_seconds": 900
}
```

상태 응답의 주요 값:

- `status`: `queued`, `running`, `succeeded`, `failed`, `expired`
- `phase`: `queued`, `preparing_input`, `converting`, `validating`, `completed`, `failed`
- `elapsed_seconds`, `output_bytes`, `last_activity_at`: 실제 server 작업 상태
- `progress_percent`: Hancom의 신뢰 가능한 페이지별 진행률 API가 없으므로 항상 `null`
- `delivery.status`: `not_requested`, `response_prepared`, `response_finished`, `response_aborted`,
  `response_error`, `expired`

`succeeded`를 확인한 뒤 `save_local_conversion_result`를 호출한다.

```json
{
  "job_id": "<start가_반환한_UUID>",
  "output_dir": "/Users/me/Documents/converted",
  "output_filename": "large-manual-2020.pdf",
  "timeout_seconds": 900
}
```

save tool은 remote blob의 SHA-256을 확인한 뒤 client local `output_dir`에 저장한다. `response_finished`는
server Node가 HTTP response를 socket에 write 완료한 기록이다. 실제 client filesystem 저장 완료는 save
tool의 성공 response와 `sha256`으로 확인한다. `response_aborted` 또는 `response_error`이면 save tool을
같은 `job_id`로 다시 호출할 수 있다.

## 9. direct CLI 변환

VS Code 없이 터미널에서 직접 변환할 때는 `hwp2020-mcp-convert`를 사용한다.

도움말:

```bash
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-convert --help
```

기존 동기 변환 예:

```bash
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-convert \
  --env-file "$HOME/Cloud/Devel/hwp-convert/.env.local" \
  --input "$HOME/Documents/sample.hwp" \
  --target pdf \
  --output-dir "$HOME/Documents/converted" \
  --output-filename sample-2020.pdf \
  --paper-size a4 \
  --orientation landscape \
  --timeout-seconds 900
```

성공 시 JSON으로 `output_path`, `size`, `sha256`, server job 정보가 출력된다.

큰 문서 async CLI 예:

```bash
# 1. local input upload 후 job_id 수신
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-convert start \
  --env-file "$HOME/Cloud/Devel/hwp-convert/.env.local" \
  --input /Users/me/Documents/large-manual.hwpx \
  --target pdf \
  --timeout-seconds 900

# 2. 반복 실행해 상태 확인
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-convert status \
  --env-file "$HOME/Cloud/Devel/hwp-convert/.env.local" \
  --job-id <start가_반환한_UUID>

# 3. succeeded 뒤 SHA-256 검증 후 client local directory에 저장
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-convert download \
  --env-file "$HOME/Cloud/Devel/hwp-convert/.env.local" \
  --job-id <start가_반환한_UUID> \
  --output-dir /Users/me/Documents/converted
```

`hwp2020-mcp-convert`의 subcommand를 생략하면 기존 `convert`로 해석된다. CLI와 bridge의 기본
`timeout_seconds`는 900초이며 허용 범위는 10~1800초다.

암호 HWP/HWPX는 password를 command argument에 넣지 않고 `--password-stdin`과 pipe를 사용한다. 이 flag는 대화형 prompt가 아니라 stdin 첫 줄을 원격 MCP 요청의 `password`로 전송한다.

```bash
printf '%s\n' "$HWP_DOCUMENT_PASSWORD" | \
  /opt/homebrew/bin/npx -y \
  --package=file:/absolute/path/hwp-convert-mcp-client-20260731-230819.tar.gz \
  -- \
  hwp2020-mcp-convert \
  --env-file /absolute/path/.env.local \
  --input /Users/me/Documents/locked.hwpx \
  --target pdf \
  --output-dir /Users/me/Documents/converted \
  --password-stdin
```

`HWP_DOCUMENT_PASSWORD` 값은 현재 shell에서만 설정하고 shell history, Git, `.env.local`에는 저장하지 않는다. VS Code MCP tool 사용 시에는 이 CLI flag 대신 `password` tool 인자를 사용한다.

## 10. bridge 도움말 확인

VS Code 등록 전에 bridge 도움말을 확인할 수 있다.

```bash
/opt/homebrew/bin/npx -y \
  --package=file:"$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz" \
  -- \
  hwp2020-mcp-bridge --help
```

정상이라면 기존 동기 tool과 start/status/save async tool 설명이 출력된다. 이 명령은 파일을 변환하지 않고 stdio MCP bridge 사용법만 보여준다.

## 11. remote HTTP 직접 등록

일부 MCP client는 local stdio bridge 없이 원격 Streamable HTTP MCP server를 직접 등록할 수 있다.

주의:

- 이 방식은 사용자 PC의 local path를 서버가 직접 읽는 구조가 아니다.
- MCP client가 파일 바이너리를 읽어 `input_blob`으로 전달할 수 있을 때 사용한다.
- 일반 VS Code local 파일 변환에는 stdio bridge 등록을 권장한다.

HTTP 직접 등록 예:

```json
{
  "inputs": [
    {
      "type": "promptString",
      "id": "hwp2020-mcp-token",
      "description": "HWP Convert MCP auth token",
      "password": true
    }
  ],
  "servers": {
    "hwp2020Convert": {
      "type": "http",
      "url": "<관리자가_제공한_MCP_endpoint>",
      "headers": {
        "Authorization": "Bearer ${input:hwp2020-mcp-token}"
      }
    }
  }
}
```

원격 HTTP tool 이름:

```text
convert_document
start_conversion
get_conversion_status
get_conversion_result
```

허용 top-level argument:

- `input_filename`
- `input_blob`
- `target`
- `output_filename`
- `options`
- `password`

`options` 내부 허용 key:

- `timeout_seconds`
- `clear_distribution`
- `table_patch_last_row_count`
- `disable_pdf_hwpx_fallback`
- `allow_sibling_fallbacks`
- `paper_size`
- `orientation`

각 option의 의미와 기본 사용 방침은 위 `convert_local_document` 선택 인자 설명과 같다. remote HTTP 직접 등록에서도 서버는 허용 key 외의 값을 거부한다.

async remote HTTP 호출도 start -> status -> result 순서이며, result response의 delivery 상태는
`get_conversion_status`로 확인한다. 일반 VS Code local file workflow에서는 local stdio bridge가
client-local input/output 저장을 처리하므로 이를 권장한다.

그 외 이상한 파라미터는 서버에서 거부된다.

## 12. 문제 해결

### `MCP: List Servers`에 보이지 않는 경우

아래를 확인한다.

- `.vscode/mcp.json` 또는 user MCP 설정 위치가 맞는지
- `settings.json`에 `"chat.mcp.access": "all"`이 있는지
- `command`가 `/opt/homebrew/bin/npx`처럼 절대경로인지
- `env.PATH`에 Node/npm 경로가 포함되어 있는지
- 설정 후 `Developer: Reload Window`를 실행했는지

### `npx` 또는 `node`를 찾지 못하는 경우

`command`에 `npx`만 쓰지 말고 절대경로를 사용한다.

```bash
which npx
```

확인한 경로를 `mcp.json`의 `command`에 넣는다.

### tarball을 찾지 못하는 경우

`--package=./파일명.tar.gz` 대신 `file:`이 붙은 절대경로를 사용한다.

```text
--package=file:$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-20260731-230819.tar.gz
```

### `hwp2020-mcp-convert: command not found`

사용 중인 client tarball이 오래된 버전일 수 있다. `hwp2020-mcp-convert`가 포함된 최신 client 배포본을 사용한다.

VS Code MCP bridge만 사용할 경우에는 `hwp2020-mcp-bridge`만 있어도 된다. 터미널 직접 변환에는 `hwp2020-mcp-convert`가 필요하다.

### `401 Unauthorized`

아래를 확인한다.

- `.env.local`에 `HWP2020_MCP_AUTH_TOKEN`이 있는지
- `.env.local`에 `HWP2020_MCP_SERVER_URL`이 있는지
- 토큰 앞뒤에 공백이나 따옴표가 잘못 들어가지 않았는지
- `HWP2020_MCP_SERVER_URL`이 `/mcp`까지 포함하는지

### 변환 결과가 저장되지 않는 경우

`output_dir`은 서버 경로가 아니라 사용자 PC의 local 경로다.

예:

```json
{
  "input_path": "<사용자_홈>/Documents/sample.hwp",
  "target": "pdf",
  "output_dir": "<사용자_홈>/Documents/converted"
}
```

`output_dir`이 없으면 bridge가 자동 생성한다. 단, 상위 경로에 쓰기 권한이 있어야 한다.

### 큰 문서가 timeout 되는 경우

기본 900초보다 오래 걸릴 것으로 예상되면 `timeout_seconds`를 900~1800 범위에서 명시한다. 동기
`convert_local_document` 또는 CLI `convert`는 result response까지 기다린다. 장시간 변환은
`start_local_document_conversion` 또는 CLI `start`를 사용해 먼저 `job_id`를 받고 status를 polling한다.

server 변환이 `succeeded`여도 client가 result response를 끊으면 `delivery.status`가
`response_aborted` 또는 `response_error`가 될 수 있다. 같은 job ID로 save/download를 재시도한다.

### 문서 보호 또는 출력 제한 문서

서버 정책과 Hancom Office 2020 변환 결과에 따라 출력 제한 문서는 실패할 수 있다. 실패 시 client는 실패 JSON을 반환하고 output file을 생성하지 않는다.

## 13. 사용자에게 전달할 파일

client 사용자에게는 아래만 전달하면 된다.

- `hwp-convert-mcp-client-20260731-230819.tar.gz`
- MCP server URL
- MCP auth token
- 이 문서: `HWP2020_MCP_CLIENT_SETUP.md`
